export const environment = {
  production: true,
  urlBack: '/AjaxATHFilter/wps/custom/',
  CaptchaKey: 'https://concursostorage.s3.amazonaws.com/'
};
